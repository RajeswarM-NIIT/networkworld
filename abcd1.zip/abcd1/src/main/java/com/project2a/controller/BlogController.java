package com.project2a.controller;



import java.util.Date;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.project2a.commondata.CommonData;
import com.project2a.model.Blog;
import com.project2a.service.BlogService;
import com.project2a.service.BlogServiceImpl;


@Controller
public class BlogController {

	
	
	@Autowired
	private SessionFactory sessionFactory;   
	
	@Autowired
	private BlogService blogService;   
		
	
	@RequestMapping("/blogPageReq") // from user / admin success login page
	public ModelAndView displayBlogPage(){
		System.out.print("\nBlogController - displayBlogPage()");
		ModelAndView mv = new ModelAndView("blogPage");
		mv.addObject("uname", CommonData.loginUserName);
		return mv;
	}
	
	/*
	@RequestMapping("/forumPageReq") // from user / admin success login page
	public ModelAndView displayForumPage(){
		System.out.print("\nBlogController - displayForumPage()");
		ModelAndView mv = new ModelAndView("forumPage");
		mv.addObject("uname", CommonData.loginUserName);
		return mv;
	}
	*/
	
	
	@RequestMapping("/addBlogRecordRequest") // from add blog page
	public ModelAndView addBlogDataRequest(@RequestParam(value="blogtitle")String title,@RequestParam(value="blogcontent")String content){
		System.out.print("\nBlogController - addBlogDataRequest()");
		
		Blog blog = new Blog();
		blog.setBlogTitle(title);
		blog.setBlogContent(content);
		blog.setBlogCreatedUser(CommonData.loginUserName);
		Date dt = new Date();
		//String date = dt.getYear()+"-"+dt.getMonth()+"-"+dt.getDate();	
		System.out.println(dt);
		blog.setBlogCreationDate(dt);
		blog.setBlogStatus("valid");
		
		blogService = new BlogServiceImpl(sessionFactory);
		blogService.createBlog(blog);
		
		ModelAndView mv = new ModelAndView("blogPage");
		mv.addObject("uname", CommonData.loginUserName);
		return mv;
	}
	
	
	@RequestMapping("/getBlogData")
	public @ResponseBody String getValues() {			
		String devs="";
		System.out.println("gson all blogs...");
		List <Blog> listdev = blogService.getBlogList();
		Gson gson = new Gson();
		devs=gson.toJson(listdev);	
		return devs;
	}	
	
	@RequestMapping("/getFullBlogInfoReq")// to read complete blog info (individual)
	public ModelAndView getCompleteBlog() {		
		System.out.println("BlogController - getCompleteBlog");
		ModelAndView mv = new ModelAndView("fullBlogPage");
		mv.addObject("uname", CommonData.loginUserName);
		return mv;
	}
	
	/*
	@RequestMapping("/getBlogDataInd")
	public @ResponseBody String getIndBlogData(@RequestParam(value="id")String blogid) {			
		String devs="";
		System.out.println("gson single blogs...");
		//List <Blog> listdev = blogService.getBlogList();
		int bid = Integer.parseInt(blogid);
		Blog b = blogService.getCompleteBlog(bid);
		Gson gson = new Gson();
		devs=gson.toJson(b);	
		return devs;
	}	
	*/
	
}
