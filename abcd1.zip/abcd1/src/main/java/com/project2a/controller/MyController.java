package com.project2a.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.project2a.model.Message;
import com.project2a.model.OutputMessage;
import com.project2a.commondata.CommonData;
import com.project2a.model.Blog;
import com.project2a.model.Forum;
import com.project2a.model.UserDetails;
import com.project2a.service.BlogService;
import com.project2a.service.ForumService;
import com.project2a.service.UserDetailsService;
import com.project2a.service.UserDetailsServiceImpl;

@Controller
@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST})
public class MyController {
	
 	private String loginUserName;
 	
	@Autowired
	private SessionFactory sessionFactory;   
	
	@Autowired
	private BlogService blogService;   
		
	@Autowired
	private ForumService forumService;   
			
	@Autowired
	private UserDetailsService userService;   
		
	@RequestMapping("/")
	public ModelAndView displayHomePage(){
		System.out.print("\nMyController - displayHomePage as landpage()");
		ModelAndView mv = new ModelAndView("landPage");		
		return mv;
	}	
/*
	@RequestMapping("/landPageReq")
	public ModelAndView displayLandPage(){
		System.out.print("\nMyController - displayLandPage()");
		ModelAndView mv = new ModelAndView("landPage");		
		return mv;
	}	
	*/
	
	@RequestMapping("/loginerror")
	public ModelAndView displayErrorPage(){
		System.out.print("\nMyController - displayErrorPage()");
		ModelAndView mv = new ModelAndView("loginError");		
		return mv;
	}	
	
	@RequestMapping("/loginPageReq")
	public ModelAndView displayLoginPage(){
		System.out.print("\nMyController - displayLoginPage()");
		ModelAndView mv = new ModelAndView("loginPage");		
		return mv;
	}	

	@RequestMapping(value="signUpPageReq",method=RequestMethod.POST)
	public ModelAndView displaySignUpPageSpring(@ModelAttribute("userDetails") UserDetails  userDetails){
		System.out.print("\nMyController - displaySignUpPageSpring()");
		ModelAndView mv = new ModelAndView("signUpPageSpring");		
		return mv;
	}

	
	/*
	@RequestMapping("/signUpPageReq")
	public ModelAndView displaySignUpPage(Model model){
		System.out.print("\nMyController - displaySignUpPage()");
		ModelAndView mv = new ModelAndView("signUpPageSpring");		
		return mv;
	}
	*/	
	
	@RequestMapping("/loginCheck")
	public ModelAndView loginChecking(@RequestParam(value="userid")String uid,@RequestParam(value="password")String pwd){
		System.out.print("\nMyController - loginChecking()");
		ModelAndView mv;
		//userService = new UserDetailsServiceImpl(sessionFactory);
		System.out.println("\nisValidUser - " + userService.isValidUser(uid,pwd));
		System.out.println("\nisAdminUser - " + userService.isAdminUser(uid,pwd));
		if(userService.isValidUser(uid, pwd)==true && userService.isAdminUser(uid, pwd)==true){
			loginUserName=uid;
			CommonData.loginUserName=uid;
			mv = new ModelAndView("loginSuccessAdmin");
			mv.addObject("uname", uid);
		}
		else if(userService.isValidUser(uid, pwd)==true){
			loginUserName=uid;
			CommonData.loginUserName=uid;
			mv = new ModelAndView("loginSuccessUser");
			
			mv.addObject("uname", uid);
		}
		else {
			mv = new ModelAndView("loginError");
			loginUserName="";
			CommonData.loginUserName="";
		}
		//ModelAndView mv = new ModelAndView("");		
		return mv;
	}	
	
	
	@RequestMapping(value="signUpDataUpdate", method = RequestMethod.POST)
	public ModelAndView regUser(@ModelAttribute("userDetails") UserDetails ud,@RequestParam("imagefile")MultipartFile mf,HttpServletRequest request) {
	
		/*System.out.println("regusteruser - spring");
		String filename = null;
	    byte[] bytes;
//	    if (!u.getProfilePicture().isEmpty()) {
	    try {
            
            bytes = ud.getImagefile().getBytes();
            String path = request.getSession().getServletContext().getRealPath("/resources/users/images/" + ud.getUserId() + ".jpg");
            System.out.println("Path = " + path);
            System.out.println("File name = " + ud.getImagefile().getOriginalFilename());
            File f = new File(path);
            BufferedOutputStream bs = new BufferedOutputStream(new FileOutputStream(f));
            bs.write(bytes);
            bs.close();
            System.out.println("Image uploaded");
	    }
	    catch(Exception ex){
	    	System.out.print("\nImage upload error..." + ex);	    	
	    }*/
		System.out.print("\nimg : " + mf);
		
		
		Path path=Paths.get("C://Users//Ani//workspace//Project2-A//abcd1//src//main//webapp//resources//users//images//"+ud.getUserId()+".jpg");
		ud.setImagefile(mf);
	    ud.setRole("ROLE_USER");
	    ud.setEnabled(true);	
		if (mf != null && !mf.isEmpty()) {
            try {
            	mf.transferTo(new File(path.toString()));                       	
            	System.out.println("Image Saved");
            } catch (Exception e) {
                e.printStackTrace();
                throw new RuntimeException(" image saving failed.", e);
            }
        }
	    userService.addUser(ud);
	    System.out.println("\nRecord added....");
		/*
		UserDetails ud = new UserDetails();
		
		ud.setUserId(uid);
		ud.setPassword(pwd);
		ud.setAdmin(false);
		//ud.setStatus("valid");
		ud.setEmailId(email);
		ud.setMobileNo(mobile);
		ud.setAddress(addr);
		ud.setCity(cit);
		ud.setState(st);
		ud.setCountry(cnt);		
		
		
		String filename = null;
	    byte[] bytes;
//	    if (!u.getProfilePicture().isEmpty()) {
	    try {
            
            bytes = ud.getImagefile().getBytes();
            String path = request.getSession().getServletContext().getRealPath("/resources/users/images" + ud.getUserId() + ".jpg");
            System.out.println("Path = " + path);
            System.out.println("File name = " + ud.getImagefile().getOriginalFilename());
            File f = new File(path);
            BufferedOutputStream bs = new BufferedOutputStream(new FileOutputStream(f));
            bs.write(bytes);
            bs.close();
            System.out.println("Image uploaded");
	    }
	    catch(Exception ex){
	    	System.out.print("\nImage upload error..." + ex);	    	
	    }
		userService = new UserDetailsServiceImpl(sessionFactory);
		userService.addUser(ud);		
		*/		
		ModelAndView mv = new ModelAndView("landPage");
		return mv;
	}	


	/*	
	@RequestMapping("/signUpDataUpdate")
	public ModelAndView regUser(@RequestParam(value="userid")String uid,@RequestParam(value="password")String pwd,
    		@RequestParam(value="emailid")String email,@RequestParam(value="mobilenumber")String mobile,
    		@RequestParam(value="address")String addr,@RequestParam(value="city")String cit,
    		@RequestParam(value="state")String st,@RequestParam(value="country")String cnt,
    		@RequestParam(value="image")String img,HttpServletRequest request) {
	
		System.out.println("regusteruser");
		UserDetails ud = new UserDetails();
		
		ud.setUserId(uid);
		ud.setPassword(pwd);
		ud.setAdmin(false);
		//ud.setStatus("valid");
		ud.setEmailId(email);
		ud.setMobileNo(mobile);
		ud.setAddress(addr);
		ud.setCity(cit);
		ud.setState(st);
		ud.setCountry(cnt);		
		
		
		String filename = null;
	    byte[] bytes;
//	    if (!u.getProfilePicture().isEmpty()) {
	    try {
            
            bytes = ud.getImagefile().getBytes();
            String path = request.getSession().getServletContext().getRealPath("/resources/users/images" + ud.getUserId() + ".jpg");
            System.out.println("Path = " + path);
            System.out.println("File name = " + ud.getImagefile().getOriginalFilename());
            File f = new File(path);
            BufferedOutputStream bs = new BufferedOutputStream(new FileOutputStream(f));
            bs.write(bytes);
            bs.close();
            System.out.println("Image uploaded");
	    }
	    catch(Exception ex){
	    	System.out.print("\nImage upload error..." + ex);	    	
	    }
		userService = new UserDetailsServiceImpl(sessionFactory);
		userService.addUser(ud);		
				
		ModelAndView mv = new ModelAndView("loginPage");
		return mv;
	}	
*/
/*
	
	@RequestMapping("/getBlogData")
	public @ResponseBody String getValues() {		
		
		String devs="";
		System.out.println("gson all blogs...");
		List <Blog> listdev = blogService.getBlogList();
		Gson gson = new Gson();
		devs=gson.toJson(listdev);
	
		return devs;
	}
	*/
	
	
	@RequestMapping("/getBlogDataInd")
	public @ResponseBody String getIndBlogData(@RequestParam(value="id")String blogid) {			
		String devs="";
		System.out.println("gson single blogs...");
		//List <Blog> listdev = blogService.getBlogList();
		int bid = Integer.parseInt(blogid);
		Blog b = blogService.getCompleteBlog(bid);
		Gson gson = new Gson();
		devs=gson.toJson(b);	
		return devs;
	}
	
	
	@RequestMapping("/getForumData")
	public @ResponseBody String getForumData() {			
		String forums="";
		System.out.println("gson all Forums...");
		List <Forum> listForum = forumService.getForumList();
		Gson gson = new Gson();
		forums=gson.toJson(listForum);	
		return forums;
	}

	@RequestMapping("/successUserPageSpring")
	public ModelAndView displaySignUpPageSpring(@ModelAttribute("userDetails")UserDetails ud, Principal p){
		//System.out.print("\nMyController - displaySignUpPage()");
		ModelAndView mv = new ModelAndView("loginSuccessUser");		
		mv.addObject("uname", ud.getUserId());
		return mv;
	}	

	
	//getUserDetails
	@RequestMapping("/getUserDetails")
	public ModelAndView displayUserDetails(@ModelAttribute("userDetails") UserDetails us, Principal p ){
		System.out.println("getuserdetails()");
		//System.out.print("\nMyController - displaySignUpPage()");
		UserDetails ud = userService.getUserById(p.getName());
		ModelAndView mv = new ModelAndView("userDetailsPage");		
		//mv.addObject("uname", ud.getUserId());
		mv.addObject("uname",ud.getUserId());
		String imgpath = "\\abcd1\\resources\\users\\images\\" + ud.getUserId() + ".jpg"; 
		System.out.println(ud.getImagefile());
		mv.addObject("uimg", imgpath);
		System.out.println(p.getName());
		
		//System.out.println(ud.getImagefile().toString());
		
		return mv;
	}
	
	
	@RequestMapping("/ChatPage")
	  public ModelAndView viewApplication() {
	    return new ModelAndView("chat");
	  }
	    
	  @MessageMapping("/chat")
	  @SendTo("/topic/message")
	  public OutputMessage sendMessage(Message message,Principal principal) {
		  System.out.print("\nchat processing function");
	    return new OutputMessage(message, new Date(),principal.getName());
	  }
	
	
	
	
}

