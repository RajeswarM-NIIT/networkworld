package com.project2a.service;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project2a.dao.BlogDAO;
import com.project2a.dao.BlogDAOImpl;

import com.project2a.model.Blog;

@Service
public class BlogServiceImpl implements BlogService {


	@Autowired
	private BlogDAO blogDao;
 	
	@Autowired
	private SessionFactory sessionFactory;   
		
	public BlogServiceImpl(){}
	
	public BlogServiceImpl(SessionFactory sf) {		
			this.sessionFactory = sf;		
	}
	
	@Override
	public void createBlog(Blog b) {		
		// TODO Auto-generated method stub
		blogDao = new BlogDAOImpl(sessionFactory);		
		blogDao.createBlog(b);

	}

	@Override
	public List<Blog> getBlogList() {
		// TODO Auto-generated method stub		
		List <Blog> lst = blogDao.getBlogList();
		return lst;
	}

	@Override
	public void deleteBlog(Blog b) {
		// TODO Auto-generated method stub

	}

	@Override
	public Blog getCompleteBlog(int bid) {
		// TODO Auto-generated method stub
		Blog b = blogDao.getCompleteBlog(bid);
		return b;
	}
	
	

}
