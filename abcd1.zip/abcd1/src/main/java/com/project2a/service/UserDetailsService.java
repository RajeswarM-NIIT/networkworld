package com.project2a.service;

import com.project2a.model.UserDetails;

public interface UserDetailsService {
	public boolean isValidUser(String un, String pd);
	public boolean isAdminUser(String un, String pd);
	public void addUser(UserDetails ud);
	public UserDetails getUserById(String uid);
}
