package com.project2a.service;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project2a.dao.UserDetailsDAO;
import com.project2a.dao.UserDetailsDAOImpl;
import com.project2a.model.UserDetails;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private UserDetailsDAO userDao;
 	
	@Autowired
	private SessionFactory sessionFactory;   
	
	public UserDetailsServiceImpl() {}
	
	public UserDetailsServiceImpl(SessionFactory sf) {
		sessionFactory=sf;		
	}	
	
	@Override
	public boolean isValidUser(String un, String pd) {
		// TODO Auto-generated method stub
		userDao = new UserDetailsDAOImpl(sessionFactory);
		boolean result=userDao.isValidUser(un, pd);		
		return result;		
	}

	@Override
	public boolean isAdminUser(String un, String pd) {
		// TODO Auto-generated method stub
		//userDao = new UserDetailsDAOImpl(sessionFactory);
		boolean result=userDao.isAdminUser(un, pd);		
		return result;
	}

	@Override
	public void addUser(UserDetails ud) {
		// TODO Auto-generated method stub
		userDao = new UserDetailsDAOImpl(sessionFactory);
		userDao.addUser(ud);
	}

	@Override
	public UserDetails getUserById(String uid) {
		// TODO Auto-generated method stub
		return userDao.getUserById(uid);
	}

	
}
