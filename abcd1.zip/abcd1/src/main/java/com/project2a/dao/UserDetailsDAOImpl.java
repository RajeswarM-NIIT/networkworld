package com.project2a.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project2a.model.UserDetails;

@Repository
public class UserDetailsDAOImpl implements UserDetailsDAO {
	private boolean isAdmin;
	
	@Autowired
	private SessionFactory sessionFactory;   
	
	public UserDetailsDAOImpl() {}
		
	public UserDetailsDAOImpl(SessionFactory sessionFactory) {
		try {
			this.sessionFactory = sessionFactory;
		} catch (Exception e) {		
			e.printStackTrace();
		}
	}
	
	@Override
	@Transactional
	public boolean isValidUser(String un, String pd) {
		System.out.println("UserDetailsDAOImpl - isValidUser() started");
		String hql = "from UserDetails where UserId= '" + un + "' and " + " Password ='" + pd + "'";
		//Query query = sessionFactory.getCurrentSession().createQuery(hql);
		Query query = sessionFactory.openSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<UserDetails> list = (List<UserDetails>) query.list();		
		for(UserDetails u : list){			
			System.out.println(u.isadmin());
			this.isAdmin = u.isadmin();
		}
		if (list != null && !list.isEmpty()) {
			return true;
		}
		System.out.println("isValidUser() ended");
		return false;
	}

	@Override
	@Transactional
	public boolean isAdminUser(String un, String pd) {
		System.out.println("UserDetailsDAOImpl - isAdminUser() started");
		/*
		String hql = "from UserDetails where UserId= '" + un + "' and " + " Password ='" + pd + "'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		//Query query = sessionFactory.openSession().createQuery(hql);		
		boolean res=false;
		@SuppressWarnings("unchecked")
		List<UserDetails> list = (List<UserDetails>) query.list();
		for(UserDetails u : list){			
			System.out.println(u.isadmin());
			res = u.isadmin();
		}
		*/
		System.out.println("UserDAOImpl - isAdminUser() ended");
		return this.isAdmin;
	}

	@Override
	@Transactional
	public void addUser(UserDetails ud) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		Transaction t=s.beginTransaction();
		System.out.println("User dao impl" +  ud);
		s.saveOrUpdate(ud);
		t.commit();		
	}

	@Override
	public UserDetails getUserById(String uid) {
		// TODO Auto-generated method stub
		String hql = "from UserDetails where UserId= '" + uid + "'";
		Query query = sessionFactory.openSession().createQuery(hql);
		UserDetails udata=null;
		@SuppressWarnings("unchecked")
		List<UserDetails> list = (List<UserDetails>) query.list();		
		for(UserDetails u : list){			
			System.out.println(u.isadmin());
			this.isAdmin = u.isadmin();
			udata=u;			
		}
		return udata;	
	}

}
