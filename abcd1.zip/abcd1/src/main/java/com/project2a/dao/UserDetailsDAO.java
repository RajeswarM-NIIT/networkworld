package com.project2a.dao;

import com.project2a.model.UserDetails;

public interface UserDetailsDAO {
	public boolean isValidUser(String un, String pd);
	public boolean isAdminUser(String un, String pd);
	public void addUser(UserDetails ud);
	public UserDetails getUserById(String uid);
}
