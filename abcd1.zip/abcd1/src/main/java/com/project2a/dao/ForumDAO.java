package com.project2a.dao;

import java.util.List;

import com.project2a.model.Forum;



public interface ForumDAO {
	public void createForum(Forum f);
	public List<Forum> getForumList();
	public void deleteForum(Forum f);
	public Forum getCompleteForum(int fid);
}
