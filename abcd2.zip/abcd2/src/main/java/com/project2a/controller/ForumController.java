package com.project2a.controller;

import java.util.Date;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.project2a.commondata.CommonData;
import com.project2a.model.Blog;
import com.project2a.model.Forum;
import com.project2a.service.BlogServiceImpl;
import com.project2a.service.ForumService;
import com.project2a.service.ForumServiceImpl;

@Controller
public class ForumController {

	@Autowired
	private SessionFactory sessionFactory;   
	
	@Autowired
	private ForumService forumService;   

	
	@RequestMapping("/forumPageReq") // from user / admin success login page
	public ModelAndView displayForumPage(){
		System.out.print("\nForumController - displayForumPage()");
		ModelAndView mv = new ModelAndView("forumPage");
		mv.addObject("uname", CommonData.loginUserName);
		return mv;
	}
	

	@RequestMapping("/addForumRecordRequest") // from add forum page
	public ModelAndView addBlogDataRequest(@RequestParam(value="forumtitle")String title,@RequestParam(value="forumcontent")String content,
			@RequestParam(value="category")String category){
		System.out.print("\nForumController - addForumDataRequest()");
		
		Forum forum = new Forum();
		forum.setForumTitle(title);
		forum.setForumCategory(category);
		forum.setForumContent(content);
		forum.setForumCreatedUser(CommonData.loginUserName);
		
		Date dt = new Date();
		//String date = dt.getYear()+"-"+dt.getMonth()+"-"+dt.getDate();	
		System.out.println(dt);
		forum.setForumCreationDate(dt);
		forum.setForumStatus("valid");		
		forumService = new ForumServiceImpl(sessionFactory);
		forumService.createForum(forum);		
		ModelAndView mv = new ModelAndView("forumPage");
		mv.addObject("uname", CommonData.loginUserName);
		return mv;
	}
		
	/*
	@RequestMapping("/getForumData")
	public @ResponseBody String getForumData() {			
		String forums="";
		System.out.println("gson all Forums...");
		List <Forum> listForum = forumService.getForumList();
		Gson gson = new Gson();
		forums=gson.toJson(listForum);	
		return forums;
	}	
	*/
}
