package com.project2a.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.project2a.model.Blog;

public class BlogDAOImpl implements BlogDAO {

	@Autowired
	private SessionFactory sessionFactory;   
	
	public BlogDAOImpl(){}
	
	public BlogDAOImpl(SessionFactory sf){
		this.sessionFactory=sf;
	}
	@Override
	public void createBlog(Blog b) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		Transaction t=s.beginTransaction();
		System.out.println("Blog dao impl" +  b);
		s.saveOrUpdate(b);
		t.commit();	
	}

	@Override
	public List<Blog> getBlogList() {
		// TODO Auto-generated method stub
		List<Blog> lst;
		System.out.println("getAllBlogs()");
		Session ses = sessionFactory.openSession();
		System.out.println("getBlogList()session " + ses.isOpen());
		Query qry = ses.createQuery("from Blog where blogstatus='valid'");
		lst = qry.list();
		System.out.println(lst);
		return lst;		
		
	}

	@Override
	public void deleteBlog(Blog b) {
		// TODO Auto-generated method stub

	}

	@Override
	public Blog getCompleteBlog(int bid) {
		// TODO Auto-generated method stub
		Blog b;	
		List<Blog> lst;
		System.out.println("DAO-getCompleteBlog()");
		Session ses = sessionFactory.openSession();
		System.out.println("getBlogList()session " + ses.isOpen());
		Query qry = ses.createQuery("from Blog where blogid="+bid);
		lst = qry.list();
		b=lst.get(0);
		System.out.println(lst);
		return b;		
	}

}
