package com.project2a.service;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project2a.dao.BlogDAO;
import com.project2a.dao.BlogDAOImpl;
import com.project2a.dao.ForumDAO;
import com.project2a.dao.ForumDAOImpl;
import com.project2a.model.Blog;
import com.project2a.model.Forum;

@Service
public class ForumServiceImpl implements ForumService {

	@Autowired
	private ForumDAO forumDao;
 	
	@Autowired
	private SessionFactory sessionFactory;   
		
	public ForumServiceImpl(){}
	
	public ForumServiceImpl(SessionFactory sf) {		
			this.sessionFactory = sf;		
	}
	
	@Override
	public void createForum(Forum f) {
		// TODO Auto-generated method stub
		System.out.print("\nForumServiceImpl - createForum");
		forumDao = new ForumDAOImpl(sessionFactory);		
		forumDao.createForum(f);

	}

	@Override
	public List<Forum> getForumList() {
		// TODO Auto-generated method stub
		List <Forum> lst = forumDao.getForumList();
		return lst;
	}

	@Override
	public void deleteForum(Forum f) {
		// TODO Auto-generated method stub

	}

	@Override
	public Forum getCompleteForum(int fid) {
		// TODO Auto-generated method stub
		return null;
	}

}
