package com.project2a.service;

import java.util.List;
import com.project2a.model.Forum;

public interface ForumService {

	public void createForum(Forum f);
	public List<Forum> getForumList();
	public void deleteForum(Forum f);
	public Forum getCompleteForum(int fid);
}
