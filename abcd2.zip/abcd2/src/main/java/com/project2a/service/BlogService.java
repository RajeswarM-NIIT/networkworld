package com.project2a.service;

import java.util.List;

import com.project2a.model.Blog;

public interface BlogService {	
	public void createBlog(Blog b);
	public List<Blog> getBlogList();
	public void deleteBlog(Blog b);
	public Blog getCompleteBlog(int bid);
}
