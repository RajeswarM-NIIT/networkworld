package com.project2a.commondata;

public class CommonData {
	public static String loginUserName;
}
